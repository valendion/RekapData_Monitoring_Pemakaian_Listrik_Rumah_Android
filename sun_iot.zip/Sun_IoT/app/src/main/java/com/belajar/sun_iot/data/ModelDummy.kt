package com.belajar.sun_iot.data

data class ModelDummy(
    var biaya: Int? = null,
    var kwh: Int? = null
)
