package com.belajar.sun_iot.utils

enum class RoleTools {
    wattmeter_ac,
    wattmeter_lamp,
    wattmeter_kulkas,
    wattmeter_uni
}