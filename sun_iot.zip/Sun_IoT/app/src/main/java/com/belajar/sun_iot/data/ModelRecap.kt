package com.belajar.sun_iot.data

data class ModelRecap(
    var id: Int? = null,
    var arus: String? = null,
    var biaya: String? = null,
    var daya: String? = null,
    var tegangan: String? = null,
    var kwh: String? = null,
    var waktu: String? = null,
    var created_at: String? = null,
    var updated_at: String? = null
)
