package com.belajar.sun_iot.data

data class ModelRealtime(
    var arus: Int? = null,
    var biaya: Int? = null,
    var daya: Int? = null,
    var kwh: Int? = null,
    var tegangan: Int? = null
)
