package com.belajar.sun_iot.data

data class ModelResponseRecap(
    var status: String? = null,
    var data: ArrayList<ModelRecap>? = null
)
