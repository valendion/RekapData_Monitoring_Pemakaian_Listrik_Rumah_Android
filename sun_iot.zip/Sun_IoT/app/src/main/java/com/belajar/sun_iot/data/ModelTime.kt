package com.belajar.sun_iot.data

 class ModelTime{
     val time = arrayListOf("Jam","Hari", "Minggu")
 }
